<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class MechanicOnduties extends Model
{
    //
}
